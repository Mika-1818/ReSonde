# ReSonde Dashboard - CloudPanel Deployment Guide

## Prerequisites
- CloudPanel installed on your server
- Domain `dashboard.resonde.de` pointed to your server IP
- Python 3.10+ available

---

## Step 1: Create Python Site in CloudPanel

1. Log into CloudPanel at `https://your-server-ip:8443`
2. Go to **Sites** → **Add Site**
3. Select **Create a Python Site**
4. Fill in:
   - **Domain**: `dashboard.resonde.de`
   - **Python Version**: 3.11 (or latest available)
   - **App Port**: 5000
5. Click **Create**

---

## Step 2: Upload Application Files

1. Connect via SFTP or SSH to your server
2. Navigate to your site directory:
   ```bash
   cd /home/dashboard-resonde-de/htdocs/dashboard.resonde.de
   ```
3. Upload all files from your `Server UI` folder:
   - `app.py`
   - `wsgi.py`
   - `requirements.txt`
   - `templates/` folder
   - `static/` folder

Or use `rsync`:
```bash
rsync -avz "/home/mika/ReSonde/Server UI/" user@your-server:/home/dashboard-resonde-de/htdocs/dashboard.resonde.de/
```

---

## Step 3: Install Dependencies

SSH into your server and activate the virtual environment:

```bash
cd /home/dashboard-resonde-de/htdocs/dashboard.resonde.de
source /home/dashboard-resonde-de/venv/bin/activate
pip install -r requirements.txt
pip install gunicorn
```

---

## Step 4: Configure Supervisor (Process Manager)

CloudPanel uses Supervisor to manage Python apps. Edit the config:

```bash
sudo nano /etc/supervisor/conf.d/dashboard-resonde-de.conf
```

Add/modify:
```ini
[program:dashboard-resonde-de]
command=/home/dashboard-resonde-de/venv/bin/gunicorn --worker-class geventwebsocket.gunicorn.workers.GeventWebSocketWorker --workers 1 --bind 127.0.0.1:5000 wsgi:app
directory=/home/dashboard-resonde-de/htdocs/dashboard.resonde.de
user=dashboard-resonde-de
autostart=true
autorestart=true
stderr_logfile=/var/log/supervisor/dashboard-resonde-de.err.log
stdout_logfile=/var/log/supervisor/dashboard-resonde-de.out.log
environment=PATH="/home/dashboard-resonde-de/venv/bin"
```

Reload Supervisor:
```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl restart dashboard-resonde-de
```

---

## Step 5: Configure Nginx (Reverse Proxy)

CloudPanel auto-generates Nginx config. You may need to add WebSocket support.

Edit: `/etc/nginx/sites-enabled/dashboard.resonde.de.conf`

Ensure these lines are in the `location /` block:
```nginx
location / {
    proxy_pass http://127.0.0.1:5000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

location /socket.io {
    proxy_pass http://127.0.0.1:5000/socket.io;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
}
```

Reload Nginx:
```bash
sudo systemctl reload nginx
```

---

## Step 6: Enable SSL (HTTPS)

In CloudPanel:
1. Go to **Sites** → **dashboard.resonde.de**
2. Click **SSL/TLS**
3. Click **Actions** → **New Let's Encrypt Certificate**
4. Enable **Force HTTPS**

---

## Step 7: Create Data Directory

```bash
mkdir -p /home/dashboard-resonde-de/htdocs/dashboard.resonde.de/data
chown -R dashboard-resonde-de:dashboard-resonde-de /home/dashboard-resonde-de/htdocs/dashboard.resonde.de/data
```

---

## ESP32 Endpoint

Once deployed, your ESP32 devices should POST to:
```
https://dashboard.resonde.de/api/upload
```

---

## Troubleshooting

**Check logs:**
```bash
sudo tail -f /var/log/supervisor/dashboard-resonde-de.err.log
sudo tail -f /var/log/supervisor/dashboard-resonde-de.out.log
```

**Restart app:**
```bash
sudo supervisorctl restart dashboard-resonde-de
```

**Test locally on server:**
```bash
curl http://127.0.0.1:5000/api/sondes
```
